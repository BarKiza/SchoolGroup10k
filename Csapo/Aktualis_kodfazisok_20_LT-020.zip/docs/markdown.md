# címsor 1
## címsor 2


## Felsorolások

### Számozatlan

- ez egy
- számozatlan
- felsorolás

### Számozott

1. ez már
2. számozott
3. felsorolás

### Automatikus számozás

1. itt most
1. automatikusan
1. adja meg a számokat.

## Példakód

### Soron belüli

A `<br>` a sortörést jelöli.

### Kódblokk

```css
body {
	background-color: red;
}
```

## Kiemelés

_Ez a szöveg dőlt_, __míg ez pedig félkövér__


### Táblázat

| A   | B       | C        |
|----:|:-------:|---------:|
|Nagy |Lajos    |fotós     |
|Kis  |Annamária|sportoló  |